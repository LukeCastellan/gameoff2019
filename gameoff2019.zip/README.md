# gameoff2019
"Leaps and Bounds" - A js game for https://itch.io/jam/game-off-2019

## Technical stuff

- Units: usually pixels

- coordinates refer to the __top left__ of everything